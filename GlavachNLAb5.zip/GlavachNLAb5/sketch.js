let x=200,y=200,vx=3,vy=2,r=20,col,paused=false;


function setup(){

  createCanvas(400,400);
  col=color(255,100,50);
  noStroke();
}
  function draw(){
  if(keyIsPressed) background(200);
  else if(!keyIsPressed) background(80);

  if(!paused){x+=vx;y+=vy;}
  else if(paused){x+=sin(frameCount*0.05)*0.3;}

  if(x>width-r){x=width- r;vx*=-1;col=color(random(50,255),random(50,255),random(50,255));}
  else if(x<r){x=r;vx*=-1;col=color(random(50,255),random(50,255),random(50,255));}

  if(y>height-r){y=height-r;vy*=-1;col=color(random(50,255),random(50,255),random(50,255));}
  if(y<r){y=r;vy*=-1;col=color(random(50,255),random(50,255),random(50,255));}

  for(let i=0;i<8;i++){fill(200-i*20);ellipse(20+i*46,20,8);}

  fill(col);ellipse(x,y,r*2);
}
function mouseClicked(){paused=!paused;}