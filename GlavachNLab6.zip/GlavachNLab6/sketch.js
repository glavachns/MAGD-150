let preset = [30, 90, 150, 210];
let ys = [];
let speeds = [];

function setup() {
  createCanvas(400, 400);
  console.log(preset.length);
  for (let i = 0; i < 6; i++) {
    ys[i] = 40 + i * 60;
    speeds[i] = 0.8 + i * 0.2;
  }
  console.log(ys.length);
}

function draw() {
  background(20);
  ys[0] = mouseY;
  for (let i = 0; i < ys.length; i++) {
    let x = 60 + i * 55;
    let y = ys[i];
    let s = 30 + (i * 6);
    push();
    translate(x, y);
    rotate(frameCount * 0.01 * (i + 1));
    fill(40 + i * 30, 120 + i * 10, 200 - i * 20);
    noStroke();
    rectMode(CENTER);
    rect(0, 0, s, s);
    pop();
    ys[i] += speeds[i];
    if (ys[i] > height + 30) ys[i] = -30;
  }
}