let k=[], f=[], p=[], r1,r2,r3;
function setup(){
createCanvas(400,400);
for(let i=1;i<=5;i++) k.push("Kernel"+i);
console.log("Array 1:",k);
for(let i=1;i<=5;i++) f.push("Flavor"+i);
f.splice(2,0,"Butter");
console.log("Array 2:",f);
p=k.concat(f);
console.log("Combined:",p);
let ck=k.concat(), cf=f.concat(), cp=p.concat();
r1=ck.splice(Math.floor(Math.random()*ck.length),1)[0];
r2=cf.splice(Math.floor(Math.random()*cf.length),1)[0];
r3=cp.splice(Math.floor(Math.random()*cp.length),1)[0];
console.log(r1,r2,r3); noLoop();
}
function draw(){
background(255);
textSize(14); fill(0);
text("Array 1: "+k.join(", "),10,10);
text("Array 2: "+f.join(", "),10,40);
text("Random 1: "+r1,10,70);
text("Random 2: "+r2,10,100);
text("Random 1 & 2: "+r3,10,130);
}